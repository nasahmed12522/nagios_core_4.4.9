void get_datetime_string(time_t * raw_time, char *buffer, int buffer_length, int type) 
{ }
